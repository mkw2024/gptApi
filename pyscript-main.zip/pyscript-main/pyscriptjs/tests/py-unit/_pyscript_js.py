from unittest.mock import Mock

showWarning = Mock()
define_custom_element = Mock()
